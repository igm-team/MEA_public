## zzz.R --- general functions for loading/unloading package.
#.onUnload <- function (libpath) {
#  library.dynam.unload("IGM.MEA", libpath)
#}

